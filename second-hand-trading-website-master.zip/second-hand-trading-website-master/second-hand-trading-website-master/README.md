# SecondHandTradingWebsite

## 介绍
二手交易平台

## 软件架构

### 后端技术

| 技术 | 说明 | 官网 |
| --- | --- | --- |
| SpringBoot | Web应用开发框架 | [官网](https://spring.io/projects/spring-boot) |
| MyBatis | ORM框架 | [官网](http://www.mybatis.org/mybatis-3/zh/index.html) |
| Druid | 数据库连接池 | [官网](https://github.com/alibaba/druid) |
| JWT | JWT登录支持 | [官网](https://github.com/jwtk/jjwt) |
| Lombok | Java语言增强库 | [官网](https://github.com/rzwitserloot/lombok) |
| PageHelper | MyBatis物理分页插件 | [官网](http://git.oschina.net/free/Mybatis_PageHelper) |

### 前端技术

| 技术 | 说明 | 官网 |
| --- | --- | --- |
| Vue | 前端框架 | [官网](https://vuejs.org/) |
| Vue-router | 路由框架 | [官网](https://router.vuejs.org/) |
| Element | 前端UI框架 | [官网](https://element.eleme.io) |
| Axios | 前端HTTP框架 | [官网](https://github.com/axios/axios) |

## 安装命令

npm -i

## 功能描述

### 普通用户

- 登录、注册
- 首页：搜索商品，浏览分类二手商品，发布商品、发布求助帖
- 商品详情：浏览商品简介、详情、评论，点赞商品、收藏商品、购买商品
- 社区广场：浏览不同圈子的帖子，查看帖子详情，可评论
- 求购专区：浏览用户发布的求购帖，可评论
- 系统公告：查看管理员发布的系统公告
- 留言反馈：填写反馈信息给管理员
- 聊天：客户和商家进行1对1单聊
- 个人信息管理、修改密码、买家订单管理、卖家订单管理、我发布的商品管理、我发布的帖子管理、我的求购管理、我的收货地址管理、我的收藏管理、我的反馈管理

### 管理员

- 登录、查看销量统计图表、商品分类管理、二手商品管理和审核、订单管理、圈子管理、帖子管理、求购管理、公告管理、收货地址管理、留言反馈管理、管理员管理、用户管理

## 创新点

- 支持用户之间一对一单人聊天
- 使用支付宝沙箱模拟线上真实支付场景
- 使用Echarts实时多维度统计销售数据
- 丰富的功能设计、多表数据关联查询（共16个表）

## 参考文章链接

[参考链接](https://blog.csdn.net/m0_46479461/article/details/138660927?ops_request_misc=&request_id=&biz_id=102&utm_term=springboot_vue%E7%9A%84%E4%BA%8C%E6%89%8B%E4%BA%A4%E6%98%93%E5%B9%B3%E5%8F%B0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~sobaiduweb~default-0-138660927.nonecase&spm=1018.2226.3001.4450)