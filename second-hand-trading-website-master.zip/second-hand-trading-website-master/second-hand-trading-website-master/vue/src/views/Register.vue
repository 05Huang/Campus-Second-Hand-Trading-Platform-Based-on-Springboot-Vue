<template>
  <div class="container">
    <div style="width: 900px;">
      <img src="@/assets/imgs/bg/bg.jpg" alt="" style="width: 100%;margin-top: 0px"/>
    </div>
    <div style="flex: 1;background-color: #f8f8f8">
      <div style="display:flex;align-items:center;height: 50px;background-color: white">
        <img src="@/assets/imgs/logo/logo1.png" alt="" style="width: 40px;margin-left: 20px"/>
        <span style="font-size: 24px;margin-left: 5px">江苏师范大学二手交易平台</span>
      </div>
      <div style="display:flex;align-items:center;justify-content:center;height: calc(100vh - 50px)">
        <div style="width: 400px; padding: 30px; background-color: white; border-radius: 5px;">
          <div style="display: flex;margin-bottom: 50px;font-size: 20px">
            <div style="border-bottom: 2px solid orange;padding-bottom: 10px">注册</div>
            <a style="color: #333;margin-left: 30px" href="/login">登录</a>
          </div>
          <el-form :model="form" :rules="rules" ref="formRef">
            <el-form-item prop="username">
              <el-input size="medium" prefix-icon="el-icon-user" placeholder="请输入账号" v-model="form.username"></el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input size="medium" prefix-icon="el-icon-lock" placeholder="请输入密码" show-password  v-model="form.password"></el-input>
            </el-form-item>
            <el-form-item prop="confirmPass">
              <el-input size="medium" prefix-icon="el-icon-lock" placeholder="请再次确认密码" show-password  v-model="form.confirmPass"></el-input>
            </el-form-item>
            <el-select v-model="form.role" placeholder="请选择" style="width: 100%;padding-bottom: 15px">
              <el-option label="用户" value="USER"></el-option>
            </el-select>
            <el-form-item>
              <el-button size="medium" style="width: 100%; background-color: orange; border-color: orange; color: white" @click="register">注册</el-button>
            </el-form-item>
            <!--        <div style="display: flex; align-items: center">-->
            <!--          <div style="flex: 1"></div>-->
            <!--          <div style="flex: 1; text-align: right">-->
            <!--            还没有账号？请 <a href="/register">注册</a>-->
            <!--          </div>-->
            <!--        </div>-->
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Register",
  data() {
    // 验证码校验
    const validatePassword = (rule, confirmPass, callback) => {
      if (confirmPass === '') {
        callback(new Error('请确认密码'))
      } else if (confirmPass !== this.form.password) {
        callback(new Error('两次输入的密码不一致'))
      } else {
        callback()
      }
    }
    return {
      form: {
        role:"USER",
      },
      rules: {
        username: [
          { required: true, message: '请输入账号', trigger: 'blur' },
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
        ],
        confirmPass: [
          { validator: validatePassword, trigger: 'blur' }
        ]
      }
    }
  },
  created() {

  },
  methods: {
    register() {
      this.$refs['formRef'].validate((valid) => {
        if (valid) {
          // 验证通过
          this.$request.post('/register', this.form).then(res => {
            if (res.code === '200') {
              this.$router.push('/')  // 跳转登录页面
              this.$message.success('注册成功')
            } else {
              this.$message.error(res.msg)
            }
          })
        }
      })
    }
  }
}
</script>

<style scoped>
.container {
  height: 100vh;
  overflow: hidden;
  display: flex;
}
a {
  color: #2a60c9;
}
</style>