<template>
  <div class="container">
    <div style="width: 900px;">
      <img src="@/assets/imgs/bg/bg.jpg" alt="" style="width: 100%;margin-top: 0px"/>
    </div>
    <div style="flex: 1;background-color: #f8f8f8">
      <div style="display:flex;align-items:center;height: 50px;background-color: white">
        <img src="@/assets/imgs/logo/logo1.png" alt="" style="width: 40px;margin-left: 20px"/>
        <span style="font-size: 24px;margin-left: 5px">江苏师范大学二手交易平台</span>
      </div>
      <div style="display:flex;align-items:center;justify-content:center;height: calc(100vh - 50px)">
        <div style="width: 400px; padding: 30px; background-color: white; border-radius: 5px;">
          <div style="display: flex;margin-bottom: 50px;font-size: 20px">
            <div style="border-bottom: 2px solid orange;padding-bottom: 10px">登录</div>
            <a style="color: #333;margin-left: 30px" href="/register">注册</a>
          </div>
          <el-form :model="form" :rules="rules" ref="formRef">
            <el-form-item prop="username">
              <el-input size="medium" prefix-icon="el-icon-user" placeholder="请输入账号" v-model="form.username"></el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input size="medium" prefix-icon="el-icon-lock" placeholder="请输入密码" show-password  v-model="form.password"></el-input>
            </el-form-item>
            <el-form-item prop="verCode">
              <div style="display: flex">
                <el-input v-model="form.verCode" prefix-icon="el-icon-edit" placeholder="请输入验证码" clearable></el-input>
                <img :src="captchaUrl" @click="clickImg()" style="width: 30%;height: 30px;margin-top: 1px;margin-left: 20px;" />
              </div>
            </el-form-item>
            <el-select v-model="form.role" placeholder="请选择" style="width: 100%;padding-bottom: 15px">
              <el-option label="管理员" value="ADMIN"></el-option>
              <el-option label="用户" value="USER"></el-option>
            </el-select>
            <el-form-item>
              <el-button size="medium" style="width: 100%; background-color: orange; border-color: orange; color: white" @click="login">登 录</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {
      form: {
        username:"",
        password:"",
        verCode:"",
        role: 'ADMIN'
      },
      //验证码的唯一标识
      key:"",
      captchaUrl:"",
      rules: {
        username: [
          { required: true, message: '请输入账号', trigger: 'blur' },
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
        ],
        verCode: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
        ]
      },
    }
  },
  mounted() {
    this.flush();
  },
  methods: {
    flush() {
      this.key=Math.random();
      this.captchaUrl=this.$baseUrl + `/captcha?key=${this.key}`;
      console.log(this.captchaUrl);
    },
    clickImg() {
      this.flush();
    },
    login() {
      console.log(this.form)
      this.$refs['formRef'].validate((valid) => {
        if (valid) {
          // 验证通过
          this.$request.post(`/login?key=${this.key}`, this.form).then(res => {
            if (res.code === '200') {
              localStorage.setItem("xm-user", JSON.stringify(res.data))  // 存储用户数据
              if(res.data.role === "ADMIN") {
                this.$router.push('/home')  // 跳转主页
              }
              else{
                this.$router.push('/front/home')  // 跳转主页
              }
              this.$message.success('登录成功')
            } else {
              this.$message.error(res.msg);
              this.form.verCode="";
              this.flush();
            }
          })
        }
      })
    }
  }
}
</script>

<style scoped>
.container {
  height: 100vh;
  overflow: hidden;
  display: flex;
}
a {
  color: #2a60c9;
}
</style>