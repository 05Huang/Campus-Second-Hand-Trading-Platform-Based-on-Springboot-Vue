<template>
  <div>
    <el-card style="width: 50%">
      <el-page-header @back="deleteNoImg();$router.push('/home')" content="首页"></el-page-header>
      <el-form :model="user" label-width="100px" style="padding-right: 50px" :rules="rules" ref="formRef" >
        <div style="margin: 15px; text-align: center">
          <el-upload
              class="avatar-uploader"
              :action="$baseUrl + '/files/upload'"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
          >
            <img v-if="user.avatar" :src="user.avatar" class="avatar" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </div>
        <el-form-item label="用户名" prop="username">
          <el-input v-model="user.username" placeholder="用户名" disabled></el-input>
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="user.name" placeholder="姓名"></el-input>
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="user.phone" placeholder="电话"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="user.email" placeholder="邮箱"></el-input>
        </el-form-item>
        <div style="text-align: center; margin-bottom: 20px">
          <el-button type="primary" @click="update">保 存</el-button>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script>
const imgUri = []
export default {
  name: "AdminPerson",
  data() {
    return {
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      rules: {
        name: [
          { required: true, message: '姓名不能为空', trigger: 'blur' },
        ],
        phone: [
          {pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号'}
        ],
        email: [
          {pattern: /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, message: '请输入正确的邮箱'}
        ]
      }
    }
  },
  created() {
    imgUri.push(this.user.avatar?.substring(this.user.avatar.lastIndexOf('/') + 1))
  },
  methods: {
    update() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.deleteImg();
          // 保存当前的用户信息到数据库
          this.$request.put('/admin/update', this.user).then(res => {
            if (res.code === '200') {
              // 成功更新
              this.$message.success('保存成功')

              // 更新浏览器缓存里的用户信息
              localStorage.setItem('xm-user', JSON.stringify(this.user))

              // 触发父级的数据更新
              this.$emit('update:user')
              //调用父路由组件Manager的updateUser方法
              //<!--  数据表格  -->
              // <div class="manager-main-right">
              //    <router-view @update:user="updateUser" />
              // </div>
            } else {
              this.$message.error(res.msg)
            }
          })
          imgUri.push(this.user.avatar.substring(this.user.avatar.lastIndexOf('/') + 1));
        }
      });
    },
    handleAvatarSuccess(response, file, fileList) {
      //截取最后一个/的字符串
      let fileName = response.data.substring(response.data.lastIndexOf('/') + 1)
      imgUri.push(fileName)
      // 把user的头像属性换成上传的图片的链接
      this.$set(this.user, 'avatar', response.data)
      console.log(imgUri)
    },
    deleteImg(){
      console.log(imgUri)
      if(imgUri.length > 1) {
        imgUri.pop();
        console.log(imgUri)
        this.$request.delete('/files/delete/batch', {data: imgUri})
      }
      //   清空imgUri
      imgUri.length = 0
    },
    deleteNoImg(){
      console.log(imgUri)
      // 除去user的avatar
      imgUri.splice(0, 1);
      console.log(imgUri)
      this.$request.delete('/files/delete/batch', {data: imgUri})
      //   清空imgUri
      imgUri.length = 0
    }
  }
}
</script>

<style scoped>
/deep/.el-form-item__label {
  font-weight: bold;
}
/deep/.el-upload {
  border-radius: 50%;
}
/deep/.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  border-radius: 50%;
}
/deep/.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  line-height: 120px;
  text-align: center;
  border-radius: 50%;
}
.avatar {
  width: 120px;
  height: 120px;
  display: block;
  border-radius: 50%;
}
</style>