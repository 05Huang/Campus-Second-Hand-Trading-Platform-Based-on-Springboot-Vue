<template>
  <div>
    <!--头部-->
    <div class="front-header">
      <div class="front-header-left">
        <img src="../assets/imgs/logo/logo1.png" alt="">
        <div class="title">江苏师范大学二手交易平台</div>
      </div>
      <div class="front-header-center">
      <!--   :class="{'menu-active': item.path === $route.path}"   访问哪个路由就高亮显示     -->
        <div class="menu" @click="$router.push(item.path)" v-for="item in menus" :key="item.path" :class="{'menu-active': item.path === $route.path}">{{ item.text }}</div>
        <div>
          <span @click="openMessageDialog" style="font-size: 16px; color: white; cursor: pointer;margin-left: 250px"><i class="el-icon-chat-dot-round"></i> 聊天消息</span>
        </div>
      </div>
      <div class="front-header-right">
        <div v-if="!user.username">
          <el-button @click="$router.push('/login')">登录</el-button>
          <el-button @click="$router.push('/register')">注册</el-button>
        </div>
        <div v-else>
          <el-dropdown>
            <div class="front-header-dropdown">
              <img :src="user.avatar || 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" alt="个人头像" style="border-radius: 50%">
              <div style="margin-left: 10px">
                <span style="color: white;cursor: default">{{ user.name }}</span><i class="el-icon-arrow-down" style="margin-left: 5px;cursor: pointer;color: white"></i>
              </div>
            </div>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/person')">个人信息</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/frontAddress')">收货地址</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/frontGoods')">我的商品</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/orders')">我的订单</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/collect')">我的收藏</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/userPosts')">我的帖子</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/userHelp')">我的求购</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="$router.push('/front/userFeedback')">我的反馈</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="text-decoration: none" @click="logout">退出登录</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>
    <!--主体-->
    <div class="main-body">
      <!--   定义ref可以使用父组件的方法    -->
      <router-view ref="child" @update:user="updateUser" />
    </div>
    <Footer />
  </div>

</template>

<script>
import Footer from "@/components/Footer.vue";
export default {
  name: "FrontLayout",

  data () {
    return {
      notice: [],
      user: JSON.parse(localStorage.getItem("xm-user") || '{}'),
      menus:[
        {text:'热卖专区',path:'/front/home'},
        {text:'社区广场',path:'/front/frontPosts'},
        {text:'求购专区',path:'/front/frontHelp'},
        {text:'系统公告',path:'/front/notice'},
        {text:'留言反馈',path:'/front/feedback'},
      ],
      messageDialog:false,
    }
  },
  components: {
    Footer
  },
  created() {
    this.messageDialog = true
  },
  methods: {
    updateUser() {
      this.user = JSON.parse(localStorage.getItem('xm-user') || '{}')   // 重新获取下用户的最新信息
    },
    // 退出登录
    logout() {
      localStorage.removeItem("xm-user");
      this.$router.push("/login");
    },
    openMessageDialog() {
      if (this.messageDialog) {
        this.$router.push('/front/home')
        this.messageDialog = false
      } else {
        this.$router.push('/front/chat')
        this.messageDialog = true
      }
    }
  }
}
</script>

<style scoped>
  @import "@/assets/css/front.css";
  .menu{
    color: #eee;
    font-size: 16px;
    padding: 0 20px;
    cursor: pointer;
  }
  .menu:hover {
    color: orange;
  }
  .menu-active {
    color: yellow;
  }
</style>