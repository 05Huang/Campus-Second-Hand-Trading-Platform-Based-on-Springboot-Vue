<template>
  <div style="width: 80%;margin: 10px auto" :class="{'card':total>0}">
    <div style="margin-bottom: 20px" v-if="total>0">
      <el-input placeholder="请输入主题查询" style="width: 200px" v-model="title"></el-input>
      <el-button type="info" plain style="margin-left: 10px" @click="load(1)">查询</el-button>
      <el-button type="warning" plain style="margin-left: 10px" @click="reset">重置</el-button>
    </div>

    <div class="table" v-if="total>0">
      <el-table :data="tableData">
        <el-table-column prop="title" label="主题"></el-table-column>
        <el-table-column prop="content" label="内容">
          <template v-slot="scope">
            <el-button @click="preview(scope.row.content)">显示详情</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="phone" label="联系方式"></el-table-column>
        <el-table-column prop="email" label="邮箱"></el-table-column>
        <el-table-column prop="reply" label="回复">
          <template v-slot="scope">
            {{scope.row.reply?scope.row.reply:'未回复'}}
          </template>
        </el-table-column>
        <el-table-column prop="createtime" label="创建时间"></el-table-column>
        <el-table-column label="操作" align="center" width="180">
          <template v-slot="scope">
            <el-button size="mini" type="danger" plain @click="del(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div style="margin: 15px 0;" v-if="total>pageSize">
        <el-pagination
            background
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="内容" :visible.sync="fromVisible1" width="60%" :close-on-click-modal="false" destroy-on-close>
      <div v-html="content" v-if="this.content !== '' && this.content !== null" class="w-e-text"></div>
      <div v-else class="w-e-text">暂无内容</div>
    </el-dialog>
    <el-empty style="margin-top: 20%" v-if="total<=0" description="哎呀，反馈为空呢" image="http://localhost:9090/files/empty.png"></el-empty>
  </div>
</template>
<script>
export default {
  name: "Feedback",
  data() {
    return {
      tableData: [],  // 所有的数据
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      title: null,
      form: {},
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      content: '',
      fromVisible1: false
    }
  },
  created() {
    this.load(1)
  },
  methods: {
    preview(content) {
      this.content = content
      this.fromVisible1 = true
    },
    del(id) {   // 单个删除
      this.$confirm('您确定删除吗？', '确认删除', {type: "warning"}).then(response => {
        this.$request.delete('/feedback/delete/' + id).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get('/feedback/selectPage', {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          title: this.title,
        }
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data?.list
          this.total = res.data?.total
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    reset() {
      this.title = null
      this.load(1)
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    },
  }
}
</script>

<style scoped>
.card {
  /* 背景颜色 */
  background-color: #fff;

  /* 边框样式 */
  border: 1px solid #e0e0e0;

  /* 圆角 */
  border-radius: 8px;

  /* 盒子阴影效果 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

  /* 内边距 */
  padding: 20px;

  /* 外边距 */
  margin: 20px 0;

  /* 宽度设置，可以根据实际情况调整 */
  width: 100%;

  /* 确保内容垂直居中 */
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.empty {
  text-align: center; /* 文字居中 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.empty img {
  max-width: 100%;
  max-height: 80%;
  opacity: 0.5; /* 图片透明度 */
}

.empty span {
  position: relative;
  margin-top: 10px; /* 文字与图片之间的间距 */
  font-size: 15px;
  top: -100px;
}
</style>