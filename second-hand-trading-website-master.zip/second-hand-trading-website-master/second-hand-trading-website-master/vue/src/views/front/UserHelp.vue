<template>
  <div>
    <div class="card" style="width: 90%; margin: 20px auto" v-if="total>0">
      <el-table :data="tableData">
        <el-table-column prop="title" label="标题" show-overflow-tooltip></el-table-column>
        <el-table-column prop="content" label="内容" show-overflow-tooltip></el-table-column>
        <el-table-column prop="img" label="图片">
          <template v-slot="scope">
            <el-image v-if="scope.row.img" style="width: 50px" :src="scope.row.img" :preview-src-list="[scope.row.img]"></el-image>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态">
          <template v-slot="scope">
            <el-tag type="info" v-if="scope.row.status === '待审核'">待审核</el-tag>
            <el-tag type="success" v-if="scope.row.status === '通过'">通过</el-tag>
            <el-tag type="danger" v-if="scope.row.status === '拒绝'">拒绝</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="time" label="发布时间"></el-table-column>
        <el-table-column prop="solved" label="是否解决">
          <template v-slot="scope">
            <el-tag type="info" v-if="scope.row.solved === '未解决'">未解决</el-tag>
            <el-tag type="success" v-if="scope.row.solved === '已解决'">已解决</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="220">
          <template v-slot="scope">
            <el-button v-if="scope.row.status !== '通过'" size="mini" type="warning" plain @click="handleEdit(scope.row.id)">编辑</el-button>
            <el-button size="mini" type="danger" plain @click="del(scope.row.id,scope.row.img ? scope.row.img.substring(scope.row.img.lastIndexOf('/') + 1): '')">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination" v-if="total>pageSize">
        <el-pagination
            background
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
    </div>
    <el-empty style="margin-top: 20%" v-if="total<=0" description="哎呀，求购为空呢" image="http://localhost:9090/files/empty.png"></el-empty>
  </div>
</template>

<script>
export default {
  name: "UserHelp",
  data() {
    return {
      tableData: [],  // 所有的数据
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      title: null,
      form: {},
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
    }
  },
  created() {
    this.load(1)
  },
  methods: {
    del(id,img) {   // 单个删除
      this.$confirm('您确定删除吗？', '确认删除', {type: "warning"}).then(response => {
        this.$request.delete('/help/delete/' + id).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            if(img){
              this.$request.delete(`/files/${img}`)
            }
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    handleEdit(id){
      this.$router.push(`/front/addHelp?id=${id}`);
    },
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get('/help/selectPage', {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          title: this.title,
        }
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data?.list
          this.total = res.data?.total
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    reset() {
      this.title = null
      this.load(1)
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    }
  }
}
</script>

<style scoped>
.card {
  /* 边框样式 */
  border: 1px solid #e0e0e0;
  padding: 10px 10px 10px 10px;
  /* 圆角 */
  border-radius: 8px;
  /* 盒子阴影效果 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  /* 确保内容垂直居中 */
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.pagination {
  text-align: center;
  margin-top: 10px;
}
.empty {
  text-align: center; /* 文字居中 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.empty img {
  max-width: 100%;
  max-height: 80%;
  opacity: 0.5; /* 图片透明度 */
}

.empty span {
  position: relative;
  margin-top: 10px; /* 文字与图片之间的间距 */
  font-size: 15px;
  top: -100px;
}
</style>