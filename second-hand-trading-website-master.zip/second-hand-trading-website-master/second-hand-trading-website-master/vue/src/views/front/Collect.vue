<template>
  <div class="container">
    <div class="table-container" v-if="total>0">
      <el-table :data="tableData" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" align="center"></el-table-column>
        <el-table-column prop="goodsName" label="商品名称" show-overflow-tooltip></el-table-column>
        <el-table-column label="商品图片" show-overflow-tooltip>
          <template v-slot="scope">
            <el-image v-if="scope.row.goodsImg" style="width: 50px" :src="scope.row.goodsImg" :preview-src-list="[scope.row.goodsImg]"></el-image>
          </template>
        </el-table-column>
        <el-table-column label="商品链接" show-overflow-tooltip>
          <template v-slot="scope">
            <a :href="'/front/goodsDetail?id=' + scope.row.fid" target="_blank">点击打开</a>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" align="center">
          <template v-slot="scope">
            <el-button plain type="danger" size="mini" @click="del(scope.row.id)">取消收藏</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div>
        <div class="button-container" >
          <el-button type="danger" plain @click="delBatch">批量取消</el-button>
        </div>
        <div class="pagination" v-if="total>pageSize">
          <el-pagination
              background
              @current-change="handleCurrentChange"
              :current-page="pageNum"
              :page-sizes="[5, 10, 20]"
              :page-size="pageSize"
              layout="total, prev, pager, next"
              :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-empty style="margin-top: 20%"  v-if="total<=0" description="哎呀，收藏为空呢" image="http://localhost:9090/files/empty.png"></el-empty>
  </div>
</template>

<script>
export default {
  name: "Collect",
  data() {
    return {
      tableData: [],  // 所有的数据
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      title: null,
      fromVisible: false,
      form: {},
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'), // 当前登录的用户
      ids: []
    }
  },
  created() {
    this.load(1)
  },
  methods: {
    del(id) {   // 单个删除
      this.$confirm('您确定取消收藏吗？', '确认取消', {type: "warning"}).then(response => {
        this.$request.delete('/collect/delete/' + id).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    handleSelectionChange(rows) {   // 当前选中的所有的行数据
      this.ids = rows.map(v => v.id)   //  [1,2]
    },
    delBatch() {   // 批量删除
      if (!this.ids.length) {
        this.$message.warning('请选择数据')
        return
      }
      this.$confirm('您确定批量取消收藏吗？', '确认取消', {type: "warning"}).then(response => {
        this.$request.delete('/collect/delete/batch', {data: this.ids}).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get('/collect/selectPage', {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          title: this.title,
        }
      }).then(res => {
        this.tableData = res.data?.list
        this.total = res.data?.total
      })
    },
    reset() {
      this.title = null
      this.load(1)
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    },
  }
}
</script>

<style scoped>
.container {
  width: 70%;
  margin: 0 auto;
}

.button-container {
  position: relative;
  top: 5px;
  text-align: left;
}

.table-container {
  margin-top: 30px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  padding: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.pagination {
  text-align: right; /* 居中分页 */
}

.el-table {
  font-size: 14px;
}

.el-table .cell {
  padding: 8px 0;
}

.el-button--mini {
  padding: 4px 12px;
}

.el-pagination {
  margin-top: 10px;
}

/* 商品图片 */
.el-image {
  display: inline-block;
  vertical-align: middle;
}

/* 商品链接 */
a {
  color: #409eff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

.empty {
  text-align: center; /* 文字居中 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.empty img {
  max-width: 100%;
  max-height: 80%;
  opacity: 0.5; /* 图片透明度 */
}

.empty span {
  position: relative;
  margin-top: 10px; /* 文字与图片之间的间距 */
  font-size: 15px;
  top: -100px;
}
</style>
