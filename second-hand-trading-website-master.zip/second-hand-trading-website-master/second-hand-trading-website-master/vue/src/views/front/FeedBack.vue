<template>
  <div style="display: flex; justify-content: center; align-items: center; height: 100vh;" class="container">
    <el-page-header @back="$router.push('/front/home')" content="首页" style="position: absolute; top: 60px; left: 360px;"></el-page-header>
    <div style="width: 50%;" class="card">
      <div style="font-size: 20px; text-align: center; margin-bottom: 20px;">请填写反馈内容</div>
      <el-form :model="form" label-width="100px" :rules="rules" ref="formRef" style="margin-right: 180px">
        <el-form-item label="主题" prop="title">
          <el-input v-model="form.title" placeholder="请输入主题"></el-input>
        </el-form-item>
        <el-form-item label="内容" prop="content">
          <el-input v-model="form.content" type="textarea" :rows="10" placeholder="请输入内容"></el-input>
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="form.phone" placeholder="请输入电话"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" placeholder="请输入邮箱"></el-input>
        </el-form-item>
        <div style="margin-left: 200px">
          <el-button type="primary" @click="save">提交反馈</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  name: "FeedBack.vue",
  data(){
    return {
      form: {},
      rules: {
        title: [
            { required: true, message: '请输入主题', trigger: 'blur' },
        ],
        content: [
            { required: true, message: '请输入内容', trigger: 'blur' },
        ],
      }
    }
  },
  methods: {
    save() {   // 保存按钮触发的逻辑  它会触发新增
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.$request({
            url: '/feedback/add',
            method: 'POST',
            data: this.form
          }).then(res => {
            if (res.code === '200') {  // 表示成功保存
              this.$message.success('反馈成功')
              this.$router.push('/front/home')
            } else {
              this.$message.error(res.msg)  // 弹出错误的信息
            }
          })
        }
      })
    },
  }
}
</script>

<style scoped>
.container {
  background-color: #f5f5f5; /* 背景颜色 */
  height: 100vh; /* 全屏高度 */
  position: relative; /* 使父容器成为相对定位 */
  display: flex; /* 使父容器成为弹性容器 */
  justify-content: center; /* 水平居中 */
  align-items: center; /* 垂直居中 */
}

.card {
  background-color: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin: 20px 0;
  width: 100%;
  display: flex;  /* 使父容器成为弹性容器 */
  flex-direction: column;  /* 确保子元素垂直排列 */
  align-items: center;  /* 水平居中 */
}

.el-form {
  width: 100%;
  max-width: 400px;  /* 设置最大宽度 */
  margin: 0 auto;  /* 居中 */
}
</style>
