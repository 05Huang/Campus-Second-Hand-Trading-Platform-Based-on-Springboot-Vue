<template>
  <div style="width: 98%;margin: 10px auto" :class="{'card': total>0,'notcard': total==0}">
    <div style="margin-bottom: 10px">
      <el-radio-group v-model="url" @change="changeOrders">
        <el-radio-button label="selectPage">我购买的订单</el-radio-button>
        <el-radio-button label="selectSalePage">我出售的订单</el-radio-button>
      </el-radio-group>
      <div style="flex: 1;margin-top: 30px" v-if="total>0">
        <el-input placeholder="请输入商品名称查询" style="width: 200px" v-model="goodsName" clearable></el-input>
        <el-input placeholder="请输入订单编号查询" style="width: 200px" v-model="orderNo" clearable></el-input>
        <el-select v-model="status" placeholder="请选择订单状态" style="width: 200px" clearable>
          <el-option label="全部" value=""></el-option>
          <el-option label="已取消" value="已取消"></el-option>
          <el-option label="待支付" value="待支付"></el-option>
          <el-option label="待发货" value="待发货"></el-option>
          <el-option label="待收货" value="待收货"></el-option>
          <el-option label="已完成" value="已完成"></el-option>
        </el-select>
        <el-button type="primary" style="margin-left: 10px" @click="search">搜索</el-button>
        <el-button type="success" style="margin-left: 10px" @click="reset">清空</el-button>
      </div>
    </div>

    <div class="table" style="margin: 10px 0;" v-if="total>0">
      <el-table :data="tableData">
        <el-table-column prop="goodsName" label="商品名称" show-overflow-tooltip></el-table-column>
        <el-table-column label="商品图片">
          <template v-slot="scope">
            <el-image v-if="scope.row.goodsImg" style="width: 50px" :src="scope.row.goodsImg" :preview-src-list="[scope.row.goodsImg]"></el-image>
          </template>
        </el-table-column>
        <el-table-column prop="orderNo" label="订单编号" show-overflow-tooltip></el-table-column>
        <el-table-column prop="total" label="总价"></el-table-column>
        <el-table-column prop="time" label="下单时间"></el-table-column>
        <el-table-column prop="payNo" label="支付单号" show-overflow-tooltip></el-table-column>
        <el-table-column prop="payTime" label="支付时间"></el-table-column>
        <el-table-column v-if="url !== 'selectPage'" prop="user" label="下单人"></el-table-column>
        <el-table-column prop="address" label="收货地址" show-overflow-tooltip></el-table-column>
        <el-table-column prop="phone" label="联系方式"></el-table-column>
        <el-table-column prop="userName" label="收货人名称"></el-table-column>
        <el-table-column v-if="url !== 'selectSalePage'" prop="saleName" label="卖家"></el-table-column>
        <el-table-column prop="status" label="订单状态">
          <template v-slot="scope">
            <el-tag type="info" v-if="scope.row.status === '已取消'">已取消</el-tag>
            <el-tag type="success" v-if="scope.row.status === '待支付'">待支付</el-tag>
            <el-tag type="danger" v-if="scope.row.status === '待发货'">待发货</el-tag>
            <el-tag type="warning" v-if="scope.row.status === '待收货'">待收货</el-tag>
            <el-tag type="primary" v-if="scope.row.status === '已完成'">已完成</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="180">
          <template v-slot="scope">
            <el-button v-if="scope.row.status === '待支付' && scope.row.userId === user.id" size="mini" type="primary" plain @click="pay(scope.row.orderNo)">支付</el-button>
            <el-button v-if="scope.row.status === '待支付'" size="mini" type="danger" plain @click="changeStatus(scope.row,'已取消')">取消</el-button>
            <el-button v-if="scope.row.status === '待发货' && scope.row.saleId === user.id" size="mini" type="info" plain @click="changeStatus(scope.row,'待收货')">发货</el-button>
            <el-button v-if="scope.row.status === '待收货' && scope.row.userId === user.id" size="mini" type="warning" plain @click="changeStatus(scope.row,'已完成')">收货</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination" style="padding-top: 20px" v-if="total>pageSize">
        <el-pagination
            background
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
    </div>
    <el-empty style="margin-top: 10%" v-if="total<=0" description="哎呀，订单为空呢" image="http://localhost:9090/files/empty.png"></el-empty>
  </div>
</template>
<script>

export default {
  name: "Orders",
  data() {
    return {
      tableData: [],  // 所有的数据
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      url:'selectPage',
      form: {},
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      goodsName: null,
      orderNo: null,
      status:""
    }
  },
  created() {
    this.load(1)
  },
  methods: {
    changeOrders(){
      this.reset();
      this.load(1);
    },
    pay(orderNo){
      window.open('http://localhost:9090/alipay/pay?orderNo=' + orderNo)
    },
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get(`/orders/${this.url}`, {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          goodsName: this.goodsName,
          orderNo: this.orderNo,
          status: this.status
        }
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data?.list
          this.total = res.data?.total
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    changeStatus(row,status){
      this.form = JSON.parse(JSON.stringify(row));
      this.form.status = status;
      this.$confirm('确定要修改订单状态吗?', '确认操作', {type: 'warning'}).then(response => {
        this.$request.put('/orders/update', this.form).then(res => {
          if (res.code === '200') {
            this.$message.success('操作成功')
            this.load(1)
          }
          else {
            this.$message.error(res.msg)
          }
        })
      }).catch(() => {
        return
      })
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    },
    search(){
      this.load(1);
    },
    reset(){
      this.goodsName = null;
      this.orderNo = null;
      this.status = "";
      this.load(1);
    }
  }
}
</script>

<style scoped>
.card {
  /* 背景颜色 */
  background-color: #fff;

  /* 边框样式 */
  border: 1px solid #e0e0e0;

  /* 圆角 */
  border-radius: 8px;

  /* 盒子阴影效果 */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

  /* 内边距 */
  padding: 20px;

  /* 外边距 */
  margin: 20px 0;

  /* 确保内容垂直居中 */
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.notcard {
  /* 内边距 */
  padding: 20px;
  /* 外边距 */
  margin: 20px 0;
  /* 确保内容垂直居中 */
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.empty {
  text-align: center; /* 文字居中 */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.empty img {
  max-width: 100%;
  max-height: 80%;
  opacity: 0.5; /* 图片透明度 */
}

.empty span {
  position: relative;
  margin-top: 10px; /* 文字与图片之间的间距 */
  font-size: 15px;
  top: -100px;
}
</style>