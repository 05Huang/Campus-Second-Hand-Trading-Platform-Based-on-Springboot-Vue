<template>
  <div style="margin: 0px auto;padding:10px;width: 50%">
    <div style="display: flex;margin-bottom: 20px">
      <img :src="goods.img" alt="商品详情" style="width: 50%;height:350px;display: block;margin-top: 30px" />
      <div style="flex: 1;width: 0;margin-top: 10px;margin-left: 5px">
        <el-tooltip :content="goods.name" placement="top-start">
          <div style="font-weight: bold;font-size: 24px;margin: 20px 20px;width: 100%" class="line1">{{ goods.name }}</div>
        </el-tooltip>
        <div style="display:flex;color: #2656b5;padding-bottom: 40px">
          <span style="margin-left: 20px;padding-right: 30px">浏览量:{{goods.readCount}}</span>
          <span style="margin-left: 20px;padding-right: 30px">点赞:{{goods.likeCount}}</span>
          <span style="margin-left: 20px;padding-right: 30px">收藏:{{goods.collectCount}}</span>
        </div>
        <div style="color: red;font-size: 25px;margin-left: 20px;padding-bottom: 40px">￥{{goods.price}}</div>
        <div style="color: #666;margin-left:20px;margin-bottom: 20px">
          <span>发货地:</span>
          {{goods.address}}
        </div>
        <div style="color: #666;margin-left:20px;margin-bottom: 20px">
          <span>卖家:</span>
          {{goods.userName}}
          <el-tooltip effect="light" content="聊天" placement="right" :hide-after="2000">
            <i @click="chat(goods.userId)" class="el-icon-chat-dot-round" style="font-size: 18px; margin-left: 3px; cursor: pointer"></i>
          </el-tooltip>
        </div>
        <div style="color: #666;margin-left:20px;margin-bottom: 20px">
          <span>发布日期:</span>
          {{goods.date}}
        </div>
        <div style="color: #666;margin-left:20px;margin-bottom: 20px">
          <el-button v-if=goods.userLikes size="medium" type="info" @click="addLikes">已点赞</el-button>
          <el-button v-else size="medium" type="info" @click="addLikes">未点赞</el-button>
          <el-button v-if=goods.userCollect size="medium" type="warning" @click="addCollect">已收藏</el-button>
          <el-button v-else size="medium" type="warning" @click="addCollect">未收藏</el-button>
          <el-button v-if="goods.saleStatus ==='上架' && goods.userName !== this.user.name" size="medium" type="danger" @click="handBuy">立即购买</el-button>
          <el-button v-if="goods.saleStatus !=='上架' && goods.userName !== this.user.name " size="medium" type="danger" disabled="true">已下架</el-button>
        </div>
      </div>
    </div>
    <div>
      <div style="display: flex;border-bottom: 1px solid darkorange">
        <div style="padding: 10px 20px;cursor: pointer" :class="{'active': current==='商品详情'}" @click="changeItem('商品详情')">商品详情</div>
        <div style="padding: 10px 20px;cursor: pointer" :class="{'active': current==='商品评论'}" @click="changeItem('商品评论')">商品评论</div>
      </div>
      <div v-if="current === '商品详情'" style="margin-top: 20px;">
        <div v-html="goods.content"></div>
      </div>
      <div v-if="current === '商品评论'" style="margin-top: 20px;" class="card">
        <Comment :fid="goods.id" :module="'goods'"/>
      </div>
    </div>

    <el-dialog title="选择收货地址" :visible.sync="dialogFormVisible" style="width: 60%;margin: 0px auto">
      <el-form :model="form">
        <div style="padding: 0 20px">
          <el-radio-group v-model="form.addressId">
            <el-radio v-for="item in addressList" :key="item.id" :label="item.id" style="margin-bottom: 10px;width: 100%">
              {{item.name + ' ' + item.address + ' ' + item.phone}}
            </el-radio>
          </el-radio-group>
          <router-link to="/front/frontAddress" style="display: block;margin-top: 10px;color: #409EFF">没有收获地址,点击前往添加</router-link>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrder">确定下单</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Comment from "@/components/Comment.vue";
  export default {
  name: "GoodsDetail",
  data(){
    return {
      user: JSON.parse(localStorage.getItem("xm-user") || '{}'),
      id:this.$route.query.id,
      goods:{},
      current: '商品详情',
      form:{},
      dialogFormVisible: false,
      addressList:[]
    }
  },
  components: {
    Comment
  },
  created() {
    this.load();
    this.$request.put("/goods/updateReadCount/"+this.id).then(res=>{
      if(res.code === '200'){
        this.load();
      }
      else{
        this.$message.error(res.msg);
      }
    });
  },
  methods:{
    chat(userId) {
      this.$request.post('/chatGroup/add', { chatUserId: userId, userId: this.user.id }).then(res => {
        this.$router.push('/front/chat')
      })
    },
    addOrder(){
      if(!this.form.addressId) {
          this.$message.warning("请选择收货地址");
          return;
      }
      this.form.goodsId = this.id;
      this.$request.post("/orders/add",this.form).then(res => {
        if (res.code === '200') {
          this.$message.success("下单成功")
          this.dialogFormVisible = false;
        }
        else {
          this.$message.error(res.msg)
        }
      })
    },
    load(){
      this.$request.get("/goods/selectById/"+this.id).then(res=>{
        this.goods = res.data;
      });
    },
    loadAddress(){
      this.$request.get("/address/selectAll").then(res=>{
        this.addressList = res.data || [];
      });
    },
    changeItem(item){
      this.current = item;
    },
    addLikes() {
      let like_text;
      if(this.goods.userLikes){
          like_text = '取消点赞成功';
      }
      else{
        like_text = '点赞成功';
      }
      this.$request.post('/likes/add',{fid:this.goods.id, module: "goods"}).then(res=>{
        if (res.code === '200') {
          this.load()
          this.$message.success(like_text)
        } else {
          this.$message.error(res.msg)
        }
      });
    },
    addCollect() {
      let like_text;
      if(this.goods.userCollect){
        like_text = '取消收藏成功';
      }
      else{
        like_text = '收藏成功';
      }
      this.$request.post('/collect/add',{fid:this.goods.id, module: "goods"}).then(res=>{
        if (res.code === '200') {
          this.load()
          this.$message.success(like_text)
        } else {
          this.$message.error(res.msg)
        }
      });
    },
    handBuy(){
      this.form={}
      this.loadAddress();
      this.dialogFormVisible = true;
    }
  }
}
</script>

<style scoped>
.active {
  color: #fff;
  background-color: #ffa500;
}
.line1 {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.card {
    /* 背景颜色 */
    background-color: #fff;

    /* 边框样式 */
    border: 1px solid #e0e0e0;

    /* 圆角 */
    border-radius: 8px;

    /* 盒子阴影效果 */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    /* 内边距 */
    padding: 20px;

    /* 外边距 */
    margin: 20px 0;

    /* 宽度设置，可以根据实际情况调整 */
    width: 100%;
    max-width: 800px;

    /* 确保内容垂直居中 */
    display: flex;
    flex-direction: column;
    justify-content: center;
}

</style>