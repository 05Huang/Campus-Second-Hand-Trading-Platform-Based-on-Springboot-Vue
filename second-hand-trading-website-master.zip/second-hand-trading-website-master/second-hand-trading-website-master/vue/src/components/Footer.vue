<template>
  <div style="height: 80px;padding: 10px 0;line-height: 30px;color: #666;text-align: center">
    <div>Copyright © 2024 - 2025 dcs 版权所有</div>
    <div>
      工商备案号：ICPxxxxx9877799
      <span style="margin-left: 20px">联系电话:19171020208</span>
    </div>
  </div>

</template>


<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>