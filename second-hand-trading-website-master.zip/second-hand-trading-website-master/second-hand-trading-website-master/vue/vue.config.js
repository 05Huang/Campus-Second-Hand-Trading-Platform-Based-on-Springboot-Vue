const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
    devServer:{
        host: '0.0.0.0',
        port:8080,
        client: {
            webSocketURL: 'ws://0.0.0.0:8080/ws',
        },
        headers: {
            'Access-Control-Allow-Origin': '*',
        }
    },
  chainWebpack: config =>{
    config.plugin('html')
        .tap(args => {
            //设置html的title(标题)
          args[0].title = "二手交易网后台管理系统";
          return args;
        })
  }
})
