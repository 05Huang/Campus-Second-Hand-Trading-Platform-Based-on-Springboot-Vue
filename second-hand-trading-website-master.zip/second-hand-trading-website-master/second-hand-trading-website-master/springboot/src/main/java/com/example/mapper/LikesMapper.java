package com.example.mapper;

import com.example.entity.Likes;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 操作likes相关数据接口
 */
public interface LikesMapper {

    @Insert("insert into likes(fid,user_id,module) values(#{fid},#{userId},#{module})")
    void insert(Likes like); //插入点赞数据

    @Delete("delete from likes where id=#{id}")
    void deleteById(Integer id); //删除点赞数据

    //查询点赞数据，根据用户id和商品id
    @Select("select * from likes where user_id=#{userId} and fid=#{fid}")
    Likes selectByUserIdAndFid(@Param("userId") Integer userId,@Param("fid") Integer fid);

    //查询点赞数
    @Select("select count(*) from likes where fid=#{fid}")
    Integer selectCountByFid(Integer fid);//商品id

    @Delete("delete from likes where fid=#{fid}")
    void deleteByFid(Integer fid);

    @Delete("delete from likes where user_id=#{userId}")
    void deleteByUserId(Integer userId);
}