package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.common.enums.RoleEnum;
import com.example.common.enums.StatusEnum;
import com.example.entity.Account;
import com.example.entity.Help;
import com.example.mapper.HelpMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 求购信息业务处理
 **/
@Service
public class HelpService {

    @Resource
    private HelpMapper helpMapper;

    /**
     * 新增
     */
    public void add(@RequestBody Help help) {
        Account user = TokenUtils.getCurrentUser();
        help.setUserId(user.getId());
        help.setTime(DateUtil.now());
        help.setStatus("待审核");
        help.setSolved("未解决");
        helpMapper.insert(help);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        helpMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            helpMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Help help) {
        Account account = TokenUtils.getCurrentUser();
        if(RoleEnum.USER.name().equals(account.getRole())){
            help.setStatus(StatusEnum.NOT_AUDIT.value);
        }
        helpMapper.updateById(help);
    }

    /**
     * 根据ID查询
     */
    public Help selectById(Integer id) {
        return helpMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Help> selectAll(Help help) {
        return helpMapper.selectAll(help);
    }

    /**
     * 后台分页查询
     */
    public PageInfo<Help> selectPage(Help help, Integer pageNum, Integer pageSize) {
        Account account = TokenUtils.getCurrentUser();
        if(RoleEnum.USER.name().equals(account.getRole())){
            help.setUserId(account.getId());
        }
        PageHelper.startPage(pageNum, pageSize);
        List<Help> list = helpMapper.selectAll(help);
        return PageInfo.of(list);
    }

    /**
     * 前台分页查询
     */
    public PageInfo<Help> selectFrontPage(Help help, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Help> list = helpMapper.selectFrontAll(help);
        return PageInfo.of(list);
    }

}