package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Comment;
import com.example.mapper.CommentMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * 评论表业务处理
 **/
@Service
public class CommentService {

    @Resource
    private CommentMapper commentMapper;

    /**
     * 新增
     */
    public void add(Comment comment) {
        comment.setTime(DateUtil.now());
        commentMapper.insert(comment);
        Integer id = comment.getId();
        if(comment.getRootId() == null && comment.getPid() == null){
            comment.setRootId(id);
        }
        else{
            //一级评论没有pid 只有rootId
            Comment parent = commentMapper.selectById(comment.getPid());
            comment.setRootId(parent.getRootId());
        }
        this.updateById(comment);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        commentMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            commentMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Comment comment) {
        commentMapper.updateById(comment);
    }

    /**
     * 根据ID查询
     */
    public Comment selectById(Integer id) {
        return commentMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Comment> selectAll(Comment comment) {
        return commentMapper.selectAll(comment);
    }

    /**
     * 分页查询
     */
    public PageInfo<Comment> selectPage(Comment comment, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Comment> list = commentMapper.selectAll(comment);
        return PageInfo.of(list);
    }

    public PageInfo<Comment> selectTree(Integer fid, String module,Integer pageNum,Integer pageSize)  {
        PageHelper.startPage(pageNum, pageSize);
        //分页根评论列表
        List<Comment> commentRoots = commentMapper.selectRoot(fid, module);
        for(Comment commentRoot : commentRoots) {
            Integer rootId = commentRoot.getId();
            List<Comment> commentChrildren = commentMapper.selectByRootId(rootId, module);
            commentRoot.setChildren(commentChrildren);
        }
        PageInfo <Comment> pageInfo = PageInfo.of(commentRoots);
        return pageInfo;
    }

    public Integer selectCount(Integer fid, String module) {
        return commentMapper.selectCount(fid, module);
    }

    /**
     * 根据给定的ID删除相关记录
     * 此方法不仅仅删除指定ID的记录，还会进行深度删除，即删除与该记录相关的所有子记录
     * @param pid 要删除的记录的ID
     */
    public void deleteDeep(Integer pid) {
        this.deleteDelete(pid);
    }

    /**
     * 递归删除评论及其子评论
     *
     * @param pid 评论的ID，用于标识需要删除的父级评论
     *            [方法执行的前置条件：传入的pid对应的评论存在]
     *            [方法执行的后置条件：传入的pid对应的评论及其所有子评论将被删除]
     */
    public void deleteDelete(Integer pid){
        // 查询与给定pid相关的所有子评论
        List<Comment> comments = commentMapper.selectByPid(pid);
        // 删除父级评论
        commentMapper.deleteById(pid);
        // 遍历所有子评论，递归调用deleteDelete方法，以删除每个子评论及其子评论
        for(Comment childComment : comments){
            this.deleteDelete(childComment.getId());
        }
    }
}