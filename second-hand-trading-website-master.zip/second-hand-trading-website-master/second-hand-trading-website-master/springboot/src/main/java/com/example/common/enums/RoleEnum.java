package com.example.common.enums;

public enum RoleEnum {
    // 角色枚举
    ADMIN,USER
}
