package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.entity.Account;
import com.example.entity.Collect;
import com.example.entity.Collect;
import com.example.mapper.CollectMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 收藏业务处理
 **/
@Service
public class CollectService {

    @Resource
    private CollectMapper collectMapper;

    /**
     * 新增
     */
    public void add(Collect collect) {
        Account account = TokenUtils.getCurrentUser();
        Integer userId = account.getId();
        Integer fid = collect.getFid();
        Collect dbLike = collectMapper.selectByUserIdAndFid(userId, fid); //判断是否已经收藏
        if (ObjectUtil.isNotNull(dbLike)) {
            collectMapper.deleteById(dbLike.getId());
        }
        else{
            collect.setUserId(userId);
            collectMapper.insert(collect);
        }
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        collectMapper.deleteById(id);
    }

    /**
     * 分页查询
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo<Collect> selectPage(Integer pageNum, Integer pageSize) {
        Account account = TokenUtils.getCurrentUser();
        PageHelper.startPage(pageNum, pageSize);
        List<Collect> list = collectMapper.selectAll(account.getId());
        return PageInfo.of(list);
    }


    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            collectMapper.deleteById(id);
        }
    }
}