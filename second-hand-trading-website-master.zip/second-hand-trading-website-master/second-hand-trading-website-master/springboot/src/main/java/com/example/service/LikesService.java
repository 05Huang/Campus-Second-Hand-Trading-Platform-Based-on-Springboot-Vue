package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.Constants;
import com.example.common.enums.ResultCodeEnum;
import com.example.common.enums.RoleEnum;
import com.example.entity.Account;
import com.example.entity.Likes;
import com.example.exception.CustomException;
import com.example.mapper.LikesMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 点赞业务处理
 **/
@Service
public class LikesService {

    @Resource
    private LikesMapper likesMapper;

    /**
     * 新增
     */
    public void add(Likes likes) {
        Account account = TokenUtils.getCurrentUser();
        Integer userId = account.getId();
        Integer fid = likes.getFid();
        Likes dbLike = likesMapper.selectByUserIdAndFid(userId, fid); //判断是否已经收藏
        if (ObjectUtil.isNotNull(dbLike)) {
            likesMapper.deleteById(dbLike.getId());
        }
        else{
            likes.setUserId(userId);
            likesMapper.insert(likes);
        }
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        likesMapper.deleteById(id);
    }


}