package com.example.controller;

import com.example.common.Result;
import com.example.entity.Comment;
import com.example.service.CommentService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;

/**
 * 评论表前端操作接口
 **/
@RestController
@RequestMapping("/comment")
public class CommentController {

    @Resource
    private CommentService commentService;

    /**
     * 新增评论
     *
     * @param comment 评论对象，包含要新增的评论的所有信息
     * @return 返回操作结果，包含状态码和消息
     */
    @PostMapping("/add")
    public Result add(@RequestBody Comment comment) {
        commentService.add(comment);
        return Result.success();
    }

    /**
     * 后台删除评论
     *
     * @param id 评论的唯一标识符
     * @return 返回操作结果，包含状态码和消息
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        commentService.deleteById(id);
        return Result.success();
    }

    /**
     * 前台删除评论
     *
     * @param id 评论的唯一标识符
     * @return 返回操作结果，包含状态码和消息
     */
    @DeleteMapping("/deleteDeep/{id}")
    public Result deleteDeleteById(@PathVariable Integer id) {
        commentService.deleteDeep(id);
        return Result.success();
    }

    /**
     * 批量删除评论
     *
     * @param ids 评论的唯一标识符列表
     * @return 返回操作结果，包含状态码和消息
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        commentService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改评论
     *
     * @param comment 评论对象，包含要修改的评论的所有信息
     * @return 返回操作结果，包含状态码和消息
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Comment comment) {
        commentService.updateById(comment);
        return Result.success();
    }

    /**
     * 根据ID查询评论
     *
     * @param id 评论的唯一标识符
     * @return 返回查询结果，包含状态码、消息和评论对象
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Comment comment = commentService.selectById(id);
        return Result.success(comment);
    }

    /**
     * 查询所有评论
     *
     * @param comment 评论对象，用于传递查询条件
     * @return 返回查询结果，包含状态码、消息和评论列表
     */
    @GetMapping("/selectAll")
    public Result selectAll(Comment comment) {
        List<Comment> list = commentService.selectAll(comment);
        return Result.success(list);
    }

    /**
     * 分页查询评论
     *
     * @param comment 评论对象，用于传递查询条件
     * @param pageNum 页码，默认为1
     * @param pageSize 每页数量，默认为10
     * @return 返回查询结果，包含状态码、消息和分页信息
     */
    @GetMapping("/selectPage")
    public Result selectPage(Comment comment,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Comment> page = commentService.selectPage(comment, pageNum, pageSize);
        return Result.success(page);
    }

    /**
     * 根据特征ID和模块名称查询评论树
     * 该方法用于从评论服务中获取特定特征和模块下的所有评论，并返回这些评论的信息
     *
     * @param fid 特征ID，用于标识特定的特征
     * @param module 模块名称，用于标识特定的模块
     * @return 返回查询到的评论列表，以Result对象封装
     */
    @GetMapping("/selectTree/{fid}/{module}")
    public Result selectPage(@PathVariable Integer fid,@PathVariable String module,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "2") Integer pageSize) {
        PageInfo<Comment> commentList = commentService.selectTree(fid,module,pageNum, pageSize);
        return Result.success(commentList);
    }

    /**
     * 根据特征ID和模块名称查询评论数量
     *
     * @param fid 特征ID，用于标识特定的特征
     * @param module 模块名称，用于标识特定的模块
     * @return 返回查询到的评论数量，以Result对象封装
     */
    @GetMapping("/selectCount/{fid}/{module}")
    public Result selectCount(@PathVariable Integer fid,@PathVariable String module) {
        Integer count = commentService.selectCount(fid,module);
        return Result.success(count);
    }
}
