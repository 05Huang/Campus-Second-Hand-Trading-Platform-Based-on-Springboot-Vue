package com.example.mapper;

import com.example.entity.Help;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

/**
 * 操作help相关数据接口
 */
public interface HelpMapper {

    /**
     * 新增
     */
    int insert(Help help);

    /**
     * 删除
     */
    int deleteById(Integer id);

    /**
     * 修改
     */
    int updateById(Help help);

    /**
     * 根据ID查询
     */
    Help selectById(Integer id);

    /**
     * 后台查询所有
     */
    List<Help> selectAll(Help help);

    /**
     * 前台查询所有
     * @param help
     * @return
     */
    List<Help> selectFrontAll(Help help);

    @Delete("delete from help where user_id=#{userId}")
    void deleteByUserId(Integer userId);
}