package com.example.common.enums;

/**
 * 订单枚举
 */
public enum OrdersEnum {
    CANCELLED("已取消"),
    PENDING_PAYMENT("待支付"),
    READY_TO_SHIP("待发货"),
    AWAITING_RECEIPT("待收货"),
    COMPLETED("已完成");

    public String value;
    OrdersEnum(String value) {
        this.value = value;
    }

}
