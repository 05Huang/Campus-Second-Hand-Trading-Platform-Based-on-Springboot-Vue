package com.example.mapper;

import com.example.entity.Collect;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作collect相关数据接口
 */
public interface CollectMapper {

    @Insert("insert into collect(fid,user_id,module) values(#{fid},#{userId},#{module})")
    void insert(Collect like); //插入收藏数据

    @Delete("delete from collect where id=#{id}")
    void deleteById(Integer id); //删除收藏数据

    //查询收藏数据，根据用户id和商品id
    @Select("select * from collect where user_id=#{userId} and fid=#{fid}")
    Collect selectByUserIdAndFid(@Param("userId") Integer userId,@Param("fid") Integer fid);

    //查询收藏数据，根据商品id
    @Select("select count(*) from collect where fid=#{fid}")
    Integer selectCountByFid(Integer fid); //查询收藏数量

    //查询所有收藏数据
    @Select("select collect.*,goods.name as goodsName,goods.img as goodsImg from collect left join goods on goods.id=collect.fid where collect.user_id=#{userId} order by collect.id desc")
    List<Collect> selectAll(Integer userId);

    @Delete("delete from collect where fid=#{fid}")
    void deleteByFid(Integer fid);

    @Delete("delete from collect where user_id=#{userId}")
    void deleteByUserId(Integer userId);
}