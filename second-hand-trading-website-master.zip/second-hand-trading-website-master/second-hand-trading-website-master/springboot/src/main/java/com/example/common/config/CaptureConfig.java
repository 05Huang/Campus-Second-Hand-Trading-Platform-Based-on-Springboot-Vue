package com.example.common.config;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class CaptureConfig {
    public static Map<String,String> CAPTURE_CONFIG = new HashMap<>();
}
