package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.common.enums.RoleEnum;
import com.example.common.enums.StatusEnum;
import com.example.entity.Account;
import com.example.entity.Collect;
import com.example.entity.Goods;
import com.example.entity.Likes;
import com.example.mapper.CollectMapper;
import com.example.mapper.GoodsMapper;
import com.example.mapper.LikesMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import javax.annotation.Resource;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * 二手商品业务处理
 **/
@Service
public class GoodsService {

    @Resource
    private GoodsMapper goodsMapper;

    @Resource
    private LikesMapper likesMapper;

    @Resource
    private CollectMapper collectMapper;

    /**
     * 新增
     */
    public void add(Goods goods) {
        goods.setDate(DateUtil.now());
        Account user = TokenUtils.getCurrentUser();
        goods.setUserId(user.getId());
        goods.setStatus(StatusEnum.NOT_AUDIT.value);
        goods.setReadCount(0);
        goodsMapper.insert(goods);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        likesMapper.deleteByFid(id);
        collectMapper.deleteByFid(id);
        goodsMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            goodsMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Goods goods) {
        Account account = TokenUtils.getCurrentUser();
        if(RoleEnum.USER.name().equals(account.getRole())){
            goods.setStatus(StatusEnum.NOT_AUDIT.value);
        }
        goodsMapper.updateById(goods);
    }

    /**
     * 根据ID查询
     */
    public Goods selectById(Integer id) {
        Goods goods = goodsMapper.selectById(id);
        Account account = TokenUtils.getCurrentUser();
        Likes likes = likesMapper.selectByUserIdAndFid(account.getId(), goods.getId());
        goods.setUserLikes(likes != null);
        Collect collect = collectMapper.selectByUserIdAndFid(account.getId(), goods.getId());
        goods.setUserCollect(collect != null);
        Integer collectCount = collectMapper.selectCountByFid(goods.getId()); //收藏数
        goods.setCollectCount(collectCount);
        Integer likeCount = likesMapper.selectCountByFid(goods.getId());
        goods.setLikeCount(likeCount);
        return goods;
    }

    /**
     * 查询所有
     */
    public List<Goods> selectAll(Goods goods) {
        return goodsMapper.selectAll(goods);
    }

    /**
     * 分页查询商品信息
     *
     * @param goods 商品对象，用于作为查询条件
     * @param pageNum 页码号
     * @param pageSize 每页数据条数
     * @return 返回分页后的商品信息列表
     */
    public PageInfo<Goods> selectPage(Goods goods,Integer pageNum,Integer pageSize) {
        // 查询所有符合条件的商品信息
        Account account = TokenUtils.getCurrentUser();
        if(RoleEnum.USER.name().equals(account.getRole())){
            goods.setUserId(account.getId());
        }
        // 开始分页，设置当前页码和每页数据条数
        PageHelper.startPage(pageNum, pageSize);
        List<Goods> list = goodsMapper.selectAll(goods);
        // 对查询结果进行分页处理，返回分页信息
        return PageInfo.of(list);
    }

    public PageInfo<Goods> selectFrontPage(Goods goods, Integer pageNum, Integer pageSize) {
        Account account = TokenUtils.getCurrentUser();
        goods.setUserId(account.getId());
        PageHelper.startPage(pageNum, pageSize);
        List<Goods> list = goodsMapper.selectFrontAll(goods);
        for(Goods good : list){
            good.setLikeCount(likesMapper.selectCountByFid(good.getId()));
        }
        return PageInfo.of(list);
    }

    public void updateReadCount(Integer id) {
        goodsMapper.updateReadCount(id);
    }
}