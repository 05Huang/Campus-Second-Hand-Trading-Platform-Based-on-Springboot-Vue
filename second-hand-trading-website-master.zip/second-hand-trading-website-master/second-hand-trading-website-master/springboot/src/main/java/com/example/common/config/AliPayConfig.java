package com.example.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 配置支付宝相关的信息，使用Spring Boot的@ConfigurationProperties自动绑定配置文件中的属性。
 * 此配置类用于加载支付宝支付所需的配置信息，并在应用启动时初始化支付宝SDK。
 */
@Data
@Component
@ConfigurationProperties(prefix = "alipay")
public class AliPayConfig {

    /**
     * 应用ID，开发者在支付宝开放平台创建应用后获得。
     */
    private String appId;

    /**
     * 应用私钥，开发者生成并保存在服务器端，用于对请求签名。
     */
    private String appPrivateKey;

    /**
     * 支付宝公钥，用于验证支付宝返回的数据签名。
     */
    private String alipayPublicKey;

    /**
     * 异步通知地址，当交易状态发生变化时，支付宝会向该地址发送通知。
     */
    private String notifyUrl;

}