package com.example.controller;

import com.example.common.Result;
import com.example.entity.Collect;
import com.example.entity.Goods;
import com.example.service.CollectService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 收藏前端操作接口
 **/
@RestController
@RequestMapping("/collect")
public class CollectController {

    @Resource
    private CollectService collectService;

    /**
     * 新增收藏项
     *
     * 该方法用于接收客户端发送的新增收藏项请求，并将该收藏项添加到系统中
     * 使用了@PostMapping注解，指定该方法处理/add路径的POST请求
     * 参数collect通过@RequestBody注解接收，表示该方法的参数将从请求体中解析出来
     *
     * @param collect 要添加的收藏项对象，通过请求体传递
     * @return 返回一个Result对象，表示操作的结果，这里返回成功的结果
     */
    @PostMapping("/add")
    public Result add(@RequestBody Collect collect) {
        collectService.add(collect);
        return Result.success();
    }

    /**
     * 删除指定ID的记录
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        // 调用服务层的删除方法，传入ID
        collectService.deleteById(id);
        // 返回删除成功的结果
        return Result.success();
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(@RequestParam(defaultValue = "1") Integer pageNum,@RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Collect> page = collectService.selectPage(pageNum, pageSize);
        return Result.success(page);
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        collectService.deleteBatch(ids);
        return Result.success();
    }

}