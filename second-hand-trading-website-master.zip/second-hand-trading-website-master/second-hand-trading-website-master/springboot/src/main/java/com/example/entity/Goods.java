package com.example.entity;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 二手商品
 */
@Data
public class Goods implements Serializable {
    private static final long serialVersionUID = 1L;

    /** ID */
    private Integer id;
    /** 名称 */
    private String name;
    /** 价格 */
    private BigDecimal price;
    /** 详情 */
    private String content;
    /** 发货地址 */
    private String address;
    /** 图片 */
    private String img;
    /** 上架日期 */
    private String date;
    /** 审核状态 */
    private String status;
    /** 分类 */
    private String category;
    /** 所属用户ID */
    private Integer userId;
    /** 上架状态 */
    private String saleStatus;
    /** 浏览量 */
    private Integer readCount;
    /** 用户名 */
    private String userName;
    /** 商品排序 */
    private String sort;
    /** 用户是否点赞 */
    private Boolean userLikes;
    /** 用户是否收藏 */
    private Boolean userCollect;
    /** 收藏数量 */
    private Integer collectCount;
    /** 点赞数量 */
    private Integer likeCount;

}