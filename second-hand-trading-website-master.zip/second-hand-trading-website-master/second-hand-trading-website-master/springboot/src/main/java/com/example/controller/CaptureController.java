package com.example.controller;

import com.example.common.config.CaptureConfig;
import com.wf.captcha.base.Captcha;
import com.wf.captcha.utils.CaptchaUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.wf.captcha.SpecCaptcha;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping
public class CaptureController {

    @RequestMapping("/captcha")
    public void captcha(@RequestParam String key,HttpServletRequest request, HttpServletResponse response) throws IOException {
        //图形验证码
        SpecCaptcha specCaptcha = new SpecCaptcha(130, 48, 5);
        specCaptcha.setCharType(Captcha.TYPE_NUM_AND_UPPER);
        CaptchaUtil.out(specCaptcha, request, response);
        //将验证码存入Map
        CaptureConfig.CAPTURE_CONFIG.put(key,specCaptcha.text());
        //算数验证码
    }

}
