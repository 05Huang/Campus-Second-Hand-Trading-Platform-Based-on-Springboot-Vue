package com.example.common.enums;

public enum StatusEnum {
    // 商品发布状态
    NOT_AUDIT("待审核"),
    REFUSE("拒绝"),
    ADOPT("通过");

    public String value;

    StatusEnum(String value) {
        this.value = value;
    }

}
